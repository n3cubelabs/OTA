#### We would like to thank all the following contributors to their help in making nRFToolBox a better app!

*Note:* Before submitting a PR plese update this file with your name and a link to your profile and an optional contribution message

### Contributors:
* [Nikolaus Wittenstein](https://github.com/adzenith) CocoaPods 1.0.1 upgrade
* [Michael Petrov](https://github.com/michaelpetrov) UART sending fixes for Swift 3